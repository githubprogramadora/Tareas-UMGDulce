package gt.umg.demoumg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoumgApplicationTests {

	@Test
	void contextLoads() {
	}

}
