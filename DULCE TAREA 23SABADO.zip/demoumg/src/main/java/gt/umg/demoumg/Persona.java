/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gt.umg.demoumg;

import lombok.Data;

/**
 *
 * @author Carrillo
 */
@Data
public class Persona {
    private String nombreVendedor;
    private String  Ventaenero;
    private String  Ventafebrero;
    private String  Ventamarzo;

    
    
}
