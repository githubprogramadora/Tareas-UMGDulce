 package gt.umg.demoumg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoumgApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoumgApplication.class, args);
	}

}
